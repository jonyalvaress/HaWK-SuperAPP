package com.ssyazilim.app.ui

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.ssyazilim.app.R
import com.ssyazilim.app.data.AppPrefs
import com.ssyazilim.app.data.BlockedContactsManager
import com.ssyazilim.app.databinding.ActivityMainBinding
import com.ssyazilim.app.service.ChatAccessibilityService
import com.ssyazilim.app.service.WhatsAppNotificationListener

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var appPrefs: AppPrefs
    private lateinit var blockedContactsManager: BlockedContactsManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        appPrefs = AppPrefs(this)
        blockedContactsManager = BlockedContactsManager(this)

        loadSettingsToUi()
        setupClicks()
        refreshUi()
    }

    override fun onResume() {
        super.onResume()
        refreshUi()
    }

    private fun loadSettingsToUi() {
        binding.etGroqKey.setText(appPrefs.groqApiKey)
        binding.etGroqModel.setText(appPrefs.groqModel)
        // Persona alanı (varsa)
        binding.etPersona?.setText(appPrefs.userPersona)
    }

    private fun setupClicks() {
        binding.btnSave.setOnClickListener {
            appPrefs.groqApiKey = binding.etGroqKey.text?.toString().orEmpty()
            appPrefs.groqModel = binding.etGroqModel.text?.toString().orEmpty()
                .ifBlank { AppPrefs.DEFAULT_GROQ_MODEL }
            binding.etPersona?.text?.toString()?.let { appPrefs.userPersona = it }
            appPrefs.appendLog("💾 Ayarlar kaydedildi. Model: ${appPrefs.groqModel}")
            Toast.makeText(this, getString(R.string.toast_saved), Toast.LENGTH_SHORT).show()
            refreshUi()
        }

        binding.btnAccessibility.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        binding.btnNotifications.setOnClickListener {
            val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                Intent(Settings.ACTION_NOTIFICATION_LISTENER_DETAIL_SETTINGS).apply {
                    putExtra(
                        Settings.EXTRA_NOTIFICATION_LISTENER_COMPONENT_NAME,
                        ComponentName(this@MainActivity, WhatsAppNotificationListener::class.java).flattenToString()
                    )
                }
            } else {
                Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
            }
            startActivity(intent)
        }

        binding.btnOverlay.setOnClickListener {
            startActivity(Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                android.net.Uri.parse("package:$packageName")
            ))
        }

        binding.btnAddBlocked.setOnClickListener {
            val contact = binding.etBlockedContact.text?.toString().orEmpty().trim()
            if (contact.isBlank()) {
                Toast.makeText(this, getString(R.string.toast_empty_contact), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            blockedContactsManager.add(contact)
            binding.etBlockedContact.setText("")
            Toast.makeText(this, getString(R.string.toast_blocked_added), Toast.LENGTH_SHORT).show()
            refreshBlockedList()
        }

        binding.btnResetErrorLock.setOnClickListener {
            appPrefs.clearErrorLock()
            Toast.makeText(this, getString(R.string.toast_error_lock_reset), Toast.LENGTH_SHORT).show()
            refreshUi()
        }

        binding.btnClearLog.setOnClickListener {
            appPrefs.clearLogs()
            Toast.makeText(this, getString(R.string.toast_logs_cleared), Toast.LENGTH_SHORT).show()
            refreshUi()
        }
    }

    private fun refreshUi() {
        refreshStatus()
        refreshBlockedList()
        binding.tvLog.text = appPrefs.lastErrorLog
    }

    private fun refreshStatus() {
        val accessibility = isAccessibilityEnabled(this, ChatAccessibilityService::class.java)
        val notification = isNotificationServiceEnabled()
        val overlay = Settings.canDrawOverlays(this)

        binding.tvStatus.text = buildString {
            appendLine("${if (accessibility) "✓" else "✗"} Erişilebilirlik: ${if (accessibility) getString(R.string.status_ok) else getString(R.string.status_no)}")
            appendLine("${if (notification) "✓" else "✗"} Bildirim Dinleyici: ${if (notification) getString(R.string.status_ok) else getString(R.string.status_no)}")
            appendLine("${if (overlay) "✓" else "✗"} Overlay İzni: ${if (overlay) getString(R.string.status_ok) else getString(R.string.status_no)}")
            appendLine()
            appendLine("Hata Kilidi: ${if (appPrefs.isErrorLocked) "⛔ Aktif" else "✓ Pasif"}")
            if (appPrefs.isErrorLocked) appendLine("Neden: ${appPrefs.errorLockReason}")
            appendLine()
            appendLine("Son kişi: ${appPrefs.lastNotificationContact.ifBlank { "-" }}")
            append("Son mesaj: ${appPrefs.lastNotificationText.take(80).ifBlank { "-" }}")
        }.trimEnd()
    }

    private fun refreshBlockedList() {
        binding.blockedContainer.removeAllViews()
        val contacts = blockedContactsManager.getAll()
        if (contacts.isEmpty()) {
            binding.blockedContainer.addView(TextView(this).apply {
                text = getString(R.string.blocked_empty_text)
                setTextColor(getColor(R.color.ss_secondary))
                textSize = 13f
                setPadding(0, 8, 0, 0)
            })
            return
        }
        contacts.forEach { contact ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, 8, 0, 8)
            }
            row.addView(TextView(this).apply {
                text = "• $contact"
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                setTextColor(getColor(R.color.ss_on_surface))
                textSize = 15f
            })
            row.addView(MaterialButton(this).apply {
                text = getString(R.string.button_delete)
                textSize = 12f
                setOnClickListener {
                    blockedContactsManager.remove(contact)
                    Toast.makeText(this@MainActivity, getString(R.string.toast_blocked_removed), Toast.LENGTH_SHORT).show()
                    refreshBlockedList()
                }
            })
            binding.blockedContainer.addView(row)
        }
    }

    private fun isNotificationServiceEnabled(): Boolean {
        val flat = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return flat.contains(packageName)
    }

    private fun isAccessibilityEnabled(context: Context, service: Class<*>): Boolean {
        val am = context.getSystemService(ACCESSIBILITY_SERVICE) as AccessibilityManager
        val expected = ComponentName(context, service)
        return am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            .any { ComponentName.unflattenFromString(it.id) == expected }
    }
}
