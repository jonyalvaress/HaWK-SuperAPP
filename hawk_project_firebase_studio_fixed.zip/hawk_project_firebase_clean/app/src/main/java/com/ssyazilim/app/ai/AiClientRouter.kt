package com.ssyazilim.app.ai

import com.ssyazilim.app.data.AppPrefs

class AiClientRouter(
    appPrefs: AppPrefs
) {
    private val groqClient = GroqClient(appPrefs)

    suspend fun generateReply(prompt: String): String = groqClient.generateReply(prompt)

    suspend fun summarizeConversation(prompt: String): String = groqClient.summarizeConversation(prompt)
}
