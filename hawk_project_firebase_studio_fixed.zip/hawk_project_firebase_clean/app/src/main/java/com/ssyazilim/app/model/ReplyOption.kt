package com.ssyazilim.app.model

enum class ReplyTone {
    SOGUK,
    NORMAL,
    SAMIMI
}

data class ReplyOption(
    val tone: ReplyTone,
    val text: String
)
