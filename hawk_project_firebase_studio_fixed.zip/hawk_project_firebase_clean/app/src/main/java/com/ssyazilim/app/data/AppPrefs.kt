package com.ssyazilim.app.data

import android.content.Context
import android.content.SharedPreferences

class AppPrefs(context: Context) {

    companion object {
        private const val PREFS_NAME = "hawk_superapp_prefs"
        private const val KEY_GROQ_API_KEY = "groq_api_key"
        private const val KEY_GROQ_MODEL = "groq_model"
        private const val KEY_LAST_ERROR_LOG = "last_error_log"
        private const val KEY_LAST_FINGERPRINT = "last_fingerprint"
        private const val KEY_LAST_NOTIFICATION_CONTACT = "last_notification_contact"
        private const val KEY_LAST_NOTIFICATION_TEXT = "last_notification_text"
        private const val KEY_ERROR_LOCKED = "error_locked"
        private const val KEY_ERROR_LOCK_REASON = "error_lock_reason"
        private const val KEY_ERROR_LOCK_FINGERPRINT = "error_lock_fingerprint"
        // Yeni: kişilik / yazım tarzı
        private const val KEY_USER_PERSONA = "user_persona"
        private const val KEY_RESPONSE_LANGUAGE = "response_language"

        const val DEFAULT_GROQ_MODEL = "llama-3.3-70b-versatile"
        const val EMPTY_LOG_TEXT = "Henüz log kaydı yok."
    }

    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    var groqApiKey: String
        get() = prefs.getString(KEY_GROQ_API_KEY, "") ?: ""
        set(value) = prefs.edit().putString(KEY_GROQ_API_KEY, value.trim()).apply()

    var groqModel: String
        get() = prefs.getString(KEY_GROQ_MODEL, DEFAULT_GROQ_MODEL) ?: DEFAULT_GROQ_MODEL
        set(value) = prefs.edit().putString(KEY_GROQ_MODEL, value.trim()).apply()

    var lastErrorLog: String
        get() = prefs.getString(KEY_LAST_ERROR_LOG, EMPTY_LOG_TEXT) ?: EMPTY_LOG_TEXT
        set(value) = prefs.edit().putString(KEY_LAST_ERROR_LOG, value).apply()

    var lastFingerprint: String
        get() = prefs.getString(KEY_LAST_FINGERPRINT, "") ?: ""
        set(value) = prefs.edit().putString(KEY_LAST_FINGERPRINT, value).apply()

    var lastNotificationContact: String
        get() = prefs.getString(KEY_LAST_NOTIFICATION_CONTACT, "") ?: ""
        set(value) = prefs.edit().putString(KEY_LAST_NOTIFICATION_CONTACT, value).apply()

    var lastNotificationText: String
        get() = prefs.getString(KEY_LAST_NOTIFICATION_TEXT, "") ?: ""
        set(value) = prefs.edit().putString(KEY_LAST_NOTIFICATION_TEXT, value).apply()

    var isErrorLocked: Boolean
        get() = prefs.getBoolean(KEY_ERROR_LOCKED, false)
        set(value) = prefs.edit().putBoolean(KEY_ERROR_LOCKED, value).apply()

    var errorLockReason: String
        get() = prefs.getString(KEY_ERROR_LOCK_REASON, "") ?: ""
        set(value) = prefs.edit().putString(KEY_ERROR_LOCK_REASON, value).apply()

    var errorLockFingerprint: String
        get() = prefs.getString(KEY_ERROR_LOCK_FINGERPRINT, "") ?: ""
        set(value) = prefs.edit().putString(KEY_ERROR_LOCK_FINGERPRINT, value).apply()

    /** Kullanıcının yazım tarzı / kişilik notu (opsiyonel, boş bırakılabilir) */
    var userPersona: String
        get() = prefs.getString(KEY_USER_PERSONA, "") ?: ""
        set(value) = prefs.edit().putString(KEY_USER_PERSONA, value.trim()).apply()

    /** Cevap dili tercihi: "tr" veya "auto" */
    var responseLanguage: String
        get() = prefs.getString(KEY_RESPONSE_LANGUAGE, "tr") ?: "tr"
        set(value) = prefs.edit().putString(KEY_RESPONSE_LANGUAGE, value.trim()).apply()

    fun appendLog(message: String) {
        val timestamp = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault())
            .format(java.util.Date())
        val line = "[$timestamp] $message"
        val current = lastErrorLog
        val next = if (current.isBlank() || current == EMPTY_LOG_TEXT) {
            line
        } else {
            "$line\n$current"
        }
        lastErrorLog = next.take(16000)
    }

    fun clearLogs() {
        lastErrorLog = EMPTY_LOG_TEXT
    }

    fun lockOnError(fingerprint: String, reason: String) {
        isErrorLocked = true
        errorLockFingerprint = fingerprint
        errorLockReason = reason
        appendLog("⛔ Hata kilidi: $reason")
    }

    fun clearErrorLock() {
        isErrorLocked = false
        errorLockFingerprint = ""
        errorLockReason = ""
    }

    fun resetFingerprint() {
        lastFingerprint = ""
    }
}
