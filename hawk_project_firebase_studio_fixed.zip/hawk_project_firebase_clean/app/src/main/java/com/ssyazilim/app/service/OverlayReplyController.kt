package com.ssyazilim.app.service

import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import com.ssyazilim.app.R
import com.ssyazilim.app.data.AppPrefs
import com.ssyazilim.app.databinding.OverlayReplyBinding
import com.ssyazilim.app.model.ReplyResponse

class OverlayReplyController(
    private val context: Context,
    private val appPrefs: AppPrefs
) {
    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var binding: OverlayReplyBinding? = null
    private var overlayView: View? = null

    fun isShowing(): Boolean = overlayView != null

    fun show(
        contactName: String,
        replyResponse: ReplyResponse,
        onOptionClicked: (String) -> Unit,
        onClosed: () -> Unit,
        onCustomGenerate: (instruction: String) -> Unit
    ) {
        if (!Settings.canDrawOverlays(context)) {
            Toast.makeText(context, context.getString(R.string.toast_overlay_permission_needed), Toast.LENGTH_SHORT).show()
            return
        }
        if (isShowing()) return

        val b = OverlayReplyBinding.inflate(LayoutInflater.from(context))
        binding = b
        overlayView = b.root

        b.tvOverlayTitle.text = "${context.getString(R.string.reply_title)} — $contactName"
        setReplyButtons(b, replyResponse, onOptionClicked)

        // Beğenmedim → yazma paneline geç
        b.btnDislike.setOnClickListener {
            b.panelSuggestions.visibility = View.GONE
            b.panelCustom.visibility = View.VISIBLE
            b.btnCustomResult.visibility = View.GONE
            b.etCustomInstruction.requestFocus()
        }

        // Geri → öneri paneline dön
        b.btnBackToSuggestions.setOnClickListener {
            b.panelCustom.visibility = View.GONE
            b.panelSuggestions.visibility = View.VISIBLE
        }

        // Üret butonu
        b.btnGenCustom.setOnClickListener {
            val instruction = b.etCustomInstruction.text?.toString().orEmpty().trim()
            if (instruction.isBlank()) {
                Toast.makeText(context, "Lütfen bir şeyler yaz!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            b.btnGenCustom.isEnabled = false
            b.btnGenCustom.text = "Üretiliyor…"
            b.btnCustomResult.visibility = View.GONE
            appPrefs.appendLog("✨ Özel talimat: $instruction")
            onCustomGenerate(instruction)
        }

        // Üretilen tekil öneri tıklanınca gönder
        b.btnCustomResult.setOnClickListener {
            val text = b.btnCustomResult.text?.toString().orEmpty()
            if (text.isNotBlank()) onOptionClicked(text)
        }

        b.btnCloseOverlay.setOnClickListener {
            dismiss()
            onClosed()
        }

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        }

        try {
            windowManager.addView(b.root, params)
            appPrefs.appendLog("🪟 Overlay gösterildi: $contactName")
        } catch (e: Exception) {
            Log.e("HaWK_Overlay", "Overlay gösterilemedi", e)
            appPrefs.appendLog("❌ Overlay hatası: ${e.message}")
            overlayView = null
            binding = null
        }
    }

    /** Özel talimatla üretilen tek cevabı göster */
    fun showCustomResult(text: String, onOptionClicked: (String) -> Unit) {
        val b = binding ?: return
        b.btnGenCustom.isEnabled = true
        b.btnGenCustom.text = "✨ Üret"
        b.btnCustomResult.text = "👉 $text"
        b.btnCustomResult.visibility = View.VISIBLE
        b.btnCustomResult.setOnClickListener { onOptionClicked(text) }
        appPrefs.appendLog("✅ Özel cevap gösterildi: ${text.take(60)}")
    }

    private fun setReplyButtons(
        b: OverlayReplyBinding,
        resp: ReplyResponse,
        onOptionClicked: (String) -> Unit
    ) {
        b.btnCold.text   = "❄️ Soğuk\n${resp.cold.text}"
        b.btnNormal.text = "💬 Normal\n${resp.normal.text}"
        b.btnWarm.text   = "🤝 Samimi\n${resp.warm.text}"
        b.btnCold.setOnClickListener   { onOptionClicked(resp.cold.text) }
        b.btnNormal.setOnClickListener { onOptionClicked(resp.normal.text) }
        b.btnWarm.setOnClickListener   { onOptionClicked(resp.warm.text) }
    }

    fun dismiss() {
        overlayView?.let {
            try { windowManager.removeView(it) } catch (e: Exception) {
                Log.e("HaWK_Overlay", "Kaldırma hatası", e)
            }
        }
        overlayView = null
        binding = null
    }
}
