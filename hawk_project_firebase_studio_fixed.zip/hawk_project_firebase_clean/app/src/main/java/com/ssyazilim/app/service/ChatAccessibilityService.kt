package com.ssyazilim.app.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.ssyazilim.app.R
import com.ssyazilim.app.ai.AiClientRouter
import com.ssyazilim.app.data.AppPrefs
import com.ssyazilim.app.data.BlockedContactsManager
import com.ssyazilim.app.data.ConversationMemory
import com.ssyazilim.app.model.ReplyOption
import com.ssyazilim.app.model.ReplyResponse
import com.ssyazilim.app.model.ReplyTone
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.security.MessageDigest
import java.util.Locale

class ChatAccessibilityService : AccessibilityService() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private lateinit var appPrefs: AppPrefs
    private lateinit var blockedContactsManager: BlockedContactsManager
    private lateinit var memory: ConversationMemory
    private lateinit var aiClientRouter: AiClientRouter
    private lateinit var overlayController: OverlayReplyController
    private lateinit var errorNotifier: ErrorNotifier

    private var lastConversationContact: String = ""
    private var lastVisibleMessages: List<String> = emptyList()
    private var generationJob: Job? = null
    private var isHandlingEvent = false
    private var lastSelfWriteTimestamp: Long = 0
    private val selfWriteCooldown = 4000L

    // Debounce: event spam'i önlemek için
    private val debounceHandler = Handler(Looper.getMainLooper())
    private var pendingEventRunnable: Runnable? = null
    private val debounceDelayMs = 600L

    override fun onServiceConnected() {
        super.onServiceConnected()
        serviceInstance = this

        appPrefs = AppPrefs(this)
        blockedContactsManager = BlockedContactsManager(this)
        memory = ConversationMemory(this)
        aiClientRouter = AiClientRouter(appPrefs)
        overlayController = OverlayReplyController(this, appPrefs)
        errorNotifier = ErrorNotifier(this)

        serviceInfo = serviceInfo.apply {
            eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
                    AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            notificationTimeout = 300
            flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                    AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS or
                    AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS
        }

        appPrefs.appendLog("✅ HaWK SuperApp servisi başlatıldı.")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (event.packageName?.toString() != WHATSAPP_PACKAGE) return

        // Kullanıcı yazıyor / input alanı değişiyor — yoksay
        val sourceNode = event.source
        if (sourceNode != null &&
            (sourceNode.isEditable || sourceNode.viewIdResourceName == "com.whatsapp:id/entry")
        ) return

        // Self-write cooldown
        if (System.currentTimeMillis() - lastSelfWriteTimestamp < selfWriteCooldown) return

        // Debounce: kısa süre içinde gelen event'leri beklet
        pendingEventRunnable?.let { debounceHandler.removeCallbacks(it) }
        pendingEventRunnable = Runnable { processTrigger() }
        debounceHandler.postDelayed(pendingEventRunnable!!, debounceDelayMs)
    }

    private fun processTrigger() {
        if (isHandlingEvent || overlayController.isShowing()) return
        isHandlingEvent = true

        val root = rootInActiveWindow ?: run { isHandlingEvent = false; return }

        if (!isInWhatsAppChatScreen(root)) { isHandlingEvent = false; return }

        val contactName = resolveContactName(root)
        if (contactName.isBlank() || blockedContactsManager.isBlocked(contactName)) {
            isHandlingEvent = false
            return
        }

        val visibleMessages = collectVisibleMessages(root)
        if (visibleMessages.isEmpty()) { isHandlingEvent = false; return }

        // Kişi değiştiyse önceki konuşmayı özetle
        if (lastConversationContact.isNotBlank() &&
            lastConversationContact != contactName &&
            lastVisibleMessages.isNotEmpty()
        ) {
            summarizeAndStore(lastConversationContact, lastVisibleMessages)
        }
        lastConversationContact = contactName
        lastVisibleMessages = visibleMessages

        val fingerprint = buildFingerprint(contactName, visibleMessages)

        if (appPrefs.isErrorLocked) {
            if (appPrefs.errorLockFingerprint == fingerprint) {
                isHandlingEvent = false
                return
            }
            appPrefs.clearErrorLock()
        }

        if (appPrefs.lastFingerprint == fingerprint) {
            isHandlingEvent = false
            return
        }

        appPrefs.appendLog("📩 Yeni mesaj: $contactName")

        generationJob?.cancel()
        generationJob = scope.launch {
            try {
                // Son 5 mesajı kullan (önceki 3'ten artırıldı)
                val recentMessages = visibleMessages.takeLast(5)
                val replyResponse = buildReplyResponse(contactName, recentMessages)

                if (!overlayController.isShowing()) {
                    overlayController.show(
                        contactName = contactName,
                        replyResponse = replyResponse,
                        onOptionClicked = { selectedText ->
                            scope.launch { handleReplySelection(contactName, selectedText, fingerprint) }
                        },
                        onClosed = { appPrefs.lastFingerprint = fingerprint },
                        onCustomGenerate = { instruction ->
                            scope.launch {
                                try {
                                    val recentMessages = visibleMessages.takeLast(5)
                                    val customReply = buildCustomReply(contactName, recentMessages, instruction)
                                    overlayController.showCustomResult(customReply) { selectedText ->
                                        scope.launch { handleReplySelection(contactName, selectedText, fingerprint) }
                                    }
                                } catch (e: Exception) {
                                    appPrefs.appendLog("❌ Özel üretme hatası: ${e.message}")
                                }
                            }
                        }
                    )
                }
            } catch (e: Exception) {
                val reason = e.message ?: e.javaClass.simpleName
                appPrefs.lockOnError(fingerprint, reason)
                errorNotifier.notifyError(getString(R.string.error_notification_title), reason)
                Log.e(TAG, "Yanıt üretilemedi: $reason", e)
            } finally {
                isHandlingEvent = false
            }
        }

        if (generationJob?.isActive != true) isHandlingEvent = false
    }


    /** Kullanıcının talimatına göre TEK bir cevap üretir */
    private suspend fun buildCustomReply(
        contactName: String,
        messages: List<String>,
        instruction: String
    ): String {
        val entry = memory.getEntry(contactName)
        val prompt = buildString {
            appendLine("Sen bir WhatsApp cevap asistanısın.")
            appendLine("Kullanıcı aşağıdaki mesaja TAM OLARAK şu talimata göre cevap yazmak istiyor:")
            appendLine("TALİMAT: $instruction")
            appendLine()
            appendLine("Kişi: $contactName")
            appendLine("Geçmiş özet: ${entry.summary.ifBlank { "Yok" }}")
            appendLine()
            appendLine("Son mesajlar:")
            messages.forEachIndexed { i, m -> appendLine("${i + 1}. $m") }
            appendLine()
            appendLine("KURAL: Sadece cevabı yaz, başka hiçbir şey ekleme. Kullanıcının ağzından yaz.")
        }
        return aiClientRouter.generateReply(prompt)
    }

    // ─── Prompt ───────────────────────────────────────────────────────────────

    private suspend fun buildReplyResponse(contactName: String, messages: List<String>, feedback: String = ""): ReplyResponse {
        val entry = memory.getEntry(contactName)

        val userPersonaNote = if (appPrefs.userPersona.isNotBlank())
            "\nKullanıcının yazım tarzı notu: ${appPrefs.userPersona}" else ""

        val pastRepliesSummary = if (entry.selectedReplies.isNotEmpty())
            entry.selectedReplies.takeLast(5).joinToString("\n") { "• $it" }
        else "Yok"

        val conversationSummary = entry.summary.ifBlank { "Henüz özet yok." }

        val prompt = buildString {
            appendLine("=== GÖREV ===")
            appendLine("Sen bir WhatsApp cevap öneri motorusun. Karşı taraftan gelen SON mesajları analiz et ve kullanıcının gönderebileceği 3 farklı kısa cevap üret.")
            appendLine()
            appendLine("=== EN KRİTİK KURAL ===")
            appendLine("Tüm cevaplar KULLANICININ AĞZINDAN yazılmalı. Karşı tarafın sözlerini asla tekrarlama veya onun adına cevap yazma.")
            appendLine("Yanlış örnek — Gelen: 'Uyuyorum' → ❌ 'Özür dilerim uyumak zorundaydım' (bu karşı tarafın cümlesi)")
            appendLine("Doğru örnek — Gelen: 'Uyuyorum' → ✓ 'Tamam iyi geceler!' veya '✓ Yarın yazarım o zaman'")
            appendLine()
            appendLine("=== KURALLAR ===")
            appendLine("• Cevaplar Türkçe, kısa (max 2 cümle), doğal ve hemen gönderilebilir olsun")
            appendLine("• Açıklama, analiz, tırnak işareti olmadan sadece cevap metni yaz")
            appendLine("• Her ton belirgin şekilde farklı hissettirmeli")
            appendLine("• Sistem mesajları, tarih/saat, 'typing', 'online' gibi metinleri yoksay")
            appendLine()
            appendLine("=== KİŞİ BİLGİSİ ===")
            appendLine("Kişi adı: $contactName")
            appendLine("Geçmiş konuşma özeti: $conversationSummary")
            appendLine("Bu kişiye daha önce yazılan cevaplardan örnekler:")
            appendLine(pastRepliesSummary)
            if (userPersonaNote.isNotBlank()) appendLine(userPersonaNote)
            if (feedback.isNotBlank()) {
                appendLine()
                appendLine("=== KULLANICININ GERİ BİLDİRİMİ (BU SEFER FARKLI YAP) ===")
                appendLine(feedback)
            }
            appendLine()
            appendLine("=== ANALİZ EDİLECEK MESAJLAR (karşı taraftan gelenler) ===")
            messages.forEachIndexed { i, m -> appendLine("${i + 1}. $m") }
            appendLine()
            appendLine("=== ÇIKTI FORMATI (sadece bu 3 satır, başka hiçbir şey) ===")
            appendLine("SOGUK: <cevap>")
            appendLine("NORMAL: <cevap>")
            appendLine("SAMIMI: <cevap>")
        }

        val raw = aiClientRouter.generateReply(prompt)
        return parseReplyResponse(raw)
    }

    private fun parseReplyResponse(raw: String): ReplyResponse {
        val lines = raw.lines().map { it.trim() }.filter { it.isNotBlank() }
        fun extract(prefix: String) = lines
            .firstOrNull { it.uppercase(Locale.getDefault()).startsWith(prefix) }
            ?.substringAfter(":")?.trim().orEmpty()

        val cold = extract("SOGUK:")
        val normal = extract("NORMAL:")
        val warm = extract("SAMIMI:")

        if (cold.isBlank() || normal.isBlank() || warm.isBlank()) {
            appPrefs.appendLog("⚠️ Parse hatası. Ham: ${raw.take(200)}")
            throw IllegalStateException("Yanıt formatı beklenenden farklı. Ham: ${raw.take(100)}")
        }

        return ReplyResponse(
            cold = ReplyOption(ReplyTone.SOGUK, cold),
            normal = ReplyOption(ReplyTone.NORMAL, normal),
            warm = ReplyOption(ReplyTone.SAMIMI, warm),
            raw = raw
        )
    }

    // ─── WhatsApp'a yazma ─────────────────────────────────────────────────────

    private fun handleReplySelection(contactName: String, text: String, fingerprint: String) {
        val success = writeReplyToWhatsApp(text)
        if (success) {
            lastSelfWriteTimestamp = System.currentTimeMillis()
            appPrefs.lastFingerprint = fingerprint
            overlayController.dismiss()
            scope.launch { memory.appendSelectedReply(contactName, text) }
            appPrefs.appendLog("✅ Cevap gönderildi: ${text.take(60)}")
        } else {
            appPrefs.appendLog("❌ Cevap yazılamadı, overlay açık kalıyor.")
        }
    }

    private fun writeReplyToWhatsApp(text: String): Boolean {
        return try {
            val root = rootInActiveWindow ?: return false
            val inputNode = findMessageInputNode(root) ?: run {
                appPrefs.appendLog("❌ WhatsApp input bulunamadı.")
                return false
            }

            inputNode.performAction(AccessibilityNodeInfo.ACTION_FOCUS)

            val args = Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
            }
            if (inputNode.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) return true

            // Fallback: pano yapıştır
            appPrefs.appendLog("⚠️ SetText başarısız, pano yöntemi deneniyor.")
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("hawk_reply", text))
            inputNode.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            inputNode.performAction(AccessibilityNodeInfo.ACTION_PASTE)
        } catch (e: Exception) {
            appPrefs.appendLog("❌ writeReplyToWhatsApp istisna: ${e.message}")
            false
        }
    }

    // ─── Yardımcı ─────────────────────────────────────────────────────────────

    private fun isInWhatsAppChatScreen(root: AccessibilityNodeInfo): Boolean {
        val hasInput = findMessageInputNode(root) != null
        val hasSend = findNodeByDescription(root, "Gönder") != null ||
                findNodeByDescription(root, "Send") != null
        return hasInput && hasSend
    }

    private fun findMessageInputNode(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (node == null) return null
        if (node.viewIdResourceName == "com.whatsapp:id/entry") return node
        for (i in 0 until node.childCount) {
            val r = findMessageInputNode(node.getChild(i))
            if (r != null) return r
        }
        return null
    }

    private fun findNodeByDescription(root: AccessibilityNodeInfo, desc: String): AccessibilityNodeInfo? {
        if (root.contentDescription?.toString().equals(desc, ignoreCase = true)) return root
        for (i in 0 until root.childCount) {
            val f = findNodeByDescription(root.getChild(i) ?: continue, desc)
            if (f != null) return f
        }
        return null
    }

    private fun resolveContactName(root: AccessibilityNodeInfo): String {
        val candidates = mutableListOf<String>()
        collectTexts(root, candidates, forFingerprint = false)
        return candidates.map { it.trim() }
            .filter { it.length in 2..50 && !it.contains(":") && !isSystemText(it) }
            .firstOrNull().orEmpty()
    }

    private fun collectVisibleMessages(root: AccessibilityNodeInfo): List<String> {
        val texts = mutableListOf<String>()
        collectTexts(root, texts, forFingerprint = true)
        return texts.map { it.trim() }
            .filter { it.isNotBlank() && !isSystemText(it) }
            .distinct()
            .map { it.take(800) }
    }

    private fun collectTexts(
        node: AccessibilityNodeInfo?,
        collector: MutableList<String>,
        forFingerprint: Boolean
    ) {
        if (node == null) return
        val viewId = node.viewIdResourceName.orEmpty()

        // Input alanını tamamen atla
        if (forFingerprint && (viewId == "com.whatsapp:id/entry" ||
                    viewId.contains("footer") || viewId.contains("compose"))
        ) return

        if (node.isVisibleToUser) {
            val isMessageNode = viewId.contains("message") ||
                    node.parent?.viewIdResourceName?.contains("list") == true
            if (isMessageNode) {
                node.text?.toString()?.let { if (it.isNotBlank()) collector.add(it) }
                node.contentDescription?.toString()?.let { if (it.isNotBlank()) collector.add(it) }
            }
        }

        for (i in 0 until node.childCount) collectTexts(node.getChild(i), collector, forFingerprint)
    }

    private fun isSystemText(text: String): Boolean {
        val n = text.lowercase(Locale.getDefault())
        return n.matches(Regex(".*(ara|çalıyor|aranıyor|görüntülü|sesli|cevapsız|typing|online|bugün|dün|mesaj yaz|whatsapp).*"))
    }

    private fun buildFingerprint(contact: String, messages: List<String>): String {
        val input = "$contact||${messages.joinToString("||")}"
        val hash = MessageDigest.getInstance("SHA-256").digest(input.toByteArray())
        return hash.joinToString("") { "%02x".format(it) }
    }

    private fun summarizeAndStore(contactName: String, messages: List<String>) {
        if (contactName.isBlank() || messages.isEmpty()) return
        scope.launch(Dispatchers.IO) {
            try {
                val prompt = "Kişi: $contactName\nMesajlar:\n${messages.joinToString("\n")}"
                val summary = aiClientRouter.summarizeConversation(prompt)
                memory.saveSummary(contactName, summary)
                appPrefs.appendLog("📝 Özet kaydedildi: $contactName")
            } catch (e: Exception) {
                appPrefs.appendLog("⚠️ Özet hatası: ${e.message}")
            }
        }
    }

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        pendingEventRunnable?.let { debounceHandler.removeCallbacks(it) }
        summarizeAndStore(lastConversationContact, lastVisibleMessages)
        overlayController.dismiss()
        serviceInstance = null
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        private const val TAG = "HaWK"
        private const val WHATSAPP_PACKAGE = "com.whatsapp"

        @Volatile
        private var serviceInstance: ChatAccessibilityService? = null

        fun notifyExternalMessage(contactName: String, message: String) {
            val svc = serviceInstance ?: return
            svc.appPrefs.lastNotificationContact = contactName
            svc.appPrefs.lastNotificationText = message
            svc.appPrefs.resetFingerprint()
            svc.appPrefs.clearErrorLock()
            svc.appPrefs.appendLog("🔔 Bildirim: $contactName — ${message.take(80)}")
        }
    }
}
