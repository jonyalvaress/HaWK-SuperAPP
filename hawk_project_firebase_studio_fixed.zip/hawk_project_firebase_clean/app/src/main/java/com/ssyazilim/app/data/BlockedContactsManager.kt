package com.ssyazilim.app.data

import android.content.Context
import org.json.JSONArray

class BlockedContactsManager(context: Context) {

    companion object {
        private const val PREFS_NAME = "ss_yazilim_prefs"
        private const val KEY_LIST = "blocked_contacts"
    }

    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun getAll(): List<String> {
        val raw = prefs.getString(KEY_LIST, "[]") ?: "[]"
        return try {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) {
                    add(array.optString(i))
                }
            }.filter { it.isNotBlank() }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun add(contactName: String) {
        val normalized = contactName.trim()
        if (normalized.isBlank()) return
        val current = getAll().toMutableList()
        if (current.none { it.equals(normalized, ignoreCase = true) }) {
            current.add(normalized)
            save(current)
        }
    }

    fun remove(contactName: String) {
        val current = getAll().filterNot { it.equals(contactName.trim(), ignoreCase = true) }
        save(current)
    }

    fun isBlocked(contactName: String): Boolean {
        return getAll().any { it.equals(contactName.trim(), ignoreCase = true) }
    }

    private fun save(list: List<String>) {
        val array = JSONArray()
        list.distinct().sorted().forEach { array.put(it) }
        prefs.edit().putString(KEY_LIST, array.toString()).apply()
    }
}
