package com.ssyazilim.app.ui

import android.content.Intent
import android.os.Bundle
import android.view.animation.AnimationUtils
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.ssyazilim.app.R

class SplashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        val logo   = findViewById<ImageView>(R.id.ivSplashLogo)
        val title  = findViewById<TextView>(R.id.tvSplashTitle)
        val sub    = findViewById<TextView>(R.id.tvSplashSub)

        val logoAnim  = AnimationUtils.loadAnimation(this, R.anim.splash_logo_glow)
        val titleAnim = AnimationUtils.loadAnimation(this, R.anim.splash_title_fade)
        val subAnim   = AnimationUtils.loadAnimation(this, R.anim.splash_title_fade)

        // Görünür yap, animasyon başlasın
        logo.alpha  = 1f;  logo.startAnimation(logoAnim)
        title.alpha = 1f;  title.startAnimation(titleAnim)
        sub.alpha   = 1f;  sub.startAnimation(subAnim)

        // 2.4 sn sonra HomeActivity'e geç + fade out
        logo.postDelayed({
            val exitAnim = AnimationUtils.loadAnimation(this, R.anim.splash_exit_fade)
            findViewById<android.view.View>(android.R.id.content).startAnimation(exitAnim)
            exitAnim.setAnimationListener(object : android.view.animation.Animation.AnimationListener {
                override fun onAnimationStart(a: android.view.animation.Animation?) {}
                override fun onAnimationRepeat(a: android.view.animation.Animation?) {}
                override fun onAnimationEnd(a: android.view.animation.Animation?) {
                    startActivity(Intent(this@SplashActivity, HomeActivity::class.java))
                    finish()
                    overridePendingTransition(0, 0)
                }
            })
        }, 2400)
    }

    // Geri tuşuyla splash'tan çıkılmasın
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() = Unit
}
