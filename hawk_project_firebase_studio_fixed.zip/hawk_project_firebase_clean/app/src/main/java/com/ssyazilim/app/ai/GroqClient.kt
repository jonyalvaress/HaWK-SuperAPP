package com.ssyazilim.app.ai

import com.ssyazilim.app.data.AppPrefs
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class GroqClient(private val appPrefs: AppPrefs) {

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    /**
     * Ana yanıt üretme fonksiyonu.
     * systemPrompt: modele verilen rol/kural talimatı
     * userPrompt: kullanıcı içeriği
     */
    suspend fun generateReply(
        userPrompt: String,
        systemPrompt: String = DEFAULT_SYSTEM_PROMPT,
        temperature: Double = 0.75,
        maxTokens: Int = 600
    ): String = withContext(Dispatchers.IO) {
        val apiKey = appPrefs.groqApiKey.trim()
        require(apiKey.isNotBlank()) { "Groq API key boş. Ayarlardan giriniz." }

        val model = appPrefs.groqModel.ifBlank { AppPrefs.DEFAULT_GROQ_MODEL }

        val messages = JSONArray()
            .put(JSONObject().put("role", "system").put("content", systemPrompt))
            .put(JSONObject().put("role", "user").put("content", userPrompt))

        val body = JSONObject()
            .put("model", model)
            .put("messages", messages)
            .put("temperature", temperature)
            .put("max_tokens", maxTokens)
            .put("top_p", 0.9)

        val request = Request.Builder()
            .url(GROQ_API_URL)
            .addHeader("Authorization", "Bearer $apiKey")
            .addHeader("Content-Type", "application/json")
            .post(body.toString().toRequestBody(jsonMediaType))
            .build()

        try {
            client.newCall(request).execute().use { response ->
                val raw = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val errMsg = try {
                        JSONObject(raw).optJSONObject("error")?.optString("message") ?: raw
                    } catch (_: Exception) { raw }
                    throw IllegalStateException("Groq API hatası (${response.code}): $errMsg")
                }
                val content = JSONObject(raw)
                    .optJSONArray("choices")
                    ?.optJSONObject(0)
                    ?.optJSONObject("message")
                    ?.optString("content")
                    ?.trim()
                if (content.isNullOrBlank()) {
                    throw IllegalStateException("Groq boş yanıt döndü.")
                }
                content
            }
        } catch (e: IOException) {
            throw IllegalStateException("Ağ hatası: ${e.message ?: e.javaClass.simpleName}", e)
        }
    }

    suspend fun summarizeConversation(prompt: String): String =
        generateReply(
            userPrompt = prompt,
            systemPrompt = "Sen bir özet asistanısın. Verilen WhatsApp konuşmasını tek paragrafta, Türkçe olarak özetle. Önemli konuları ve kişinin genel tavrını belirt.",
            temperature = 0.4,
            maxTokens = 300
        )

    companion object {
        private const val GROQ_API_URL = "https://api.groq.com/openai/v1/chat/completions"
        private const val DEFAULT_SYSTEM_PROMPT =
            "Sen bir WhatsApp mesajlaşma asistanısın. Kullanıcının ağzından, kısa ve doğal Türkçe cevaplar üretirsin."
    }
}
