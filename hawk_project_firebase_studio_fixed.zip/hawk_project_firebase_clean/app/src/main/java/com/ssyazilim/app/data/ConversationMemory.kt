package com.ssyazilim.app.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Kişi bazında konuşma hafızası.
 * - summary: AI tarafından üretilmiş kısa özet
 * - selectedReplies: son 20 seçilen yanıt (en eski otomatik düşer)
 * - messageCount: toplam mesaj sayısı (istatistik)
 */
class ConversationMemory(private val context: Context) {

    companion object {
        private const val MAX_SELECTED_REPLIES = 20
        private const val MAX_SUMMARY_LENGTH = 1200
    }

    private val memoryFile: File by lazy {
        File(context.filesDir, "hawk_conversation_memory.json").apply {
            if (!exists()) writeText("{}")
        }
    }

    data class MemoryEntry(
        val summary: String = "",
        val selectedReplies: List<String> = emptyList(),
        val messageCount: Int = 0
    )

    suspend fun getEntry(contactName: String): MemoryEntry = withContext(Dispatchers.IO) {
        val root = readRoot()
        val obj = root.optJSONObject(contactName) ?: return@withContext MemoryEntry()
        val summary = obj.optString("summary", "")
        val repliesArray = obj.optJSONArray("selectedReplies") ?: JSONArray()
        val replies = (0 until repliesArray.length()).map { repliesArray.optString(it) }
        val count = obj.optInt("messageCount", 0)
        MemoryEntry(summary = summary, selectedReplies = replies, messageCount = count)
    }

    suspend fun saveSummary(contactName: String, summary: String) = withContext(Dispatchers.IO) {
        val root = readRoot()
        val obj = root.optJSONObject(contactName) ?: JSONObject()
        obj.put("summary", summary.take(MAX_SUMMARY_LENGTH))
        if (!obj.has("selectedReplies")) obj.put("selectedReplies", JSONArray())
        root.put(contactName, obj)
        writeRoot(root)
    }

    suspend fun appendSelectedReply(contactName: String, replyText: String) = withContext(Dispatchers.IO) {
        val root = readRoot()
        val obj = root.optJSONObject(contactName) ?: JSONObject()

        // Önceki yanıtları oku, sona ekle, max sınırını uygula
        val oldArray = obj.optJSONArray("selectedReplies") ?: JSONArray()
        val list = mutableListOf<String>()
        for (i in 0 until oldArray.length()) list.add(oldArray.optString(i))
        list.add(replyText)
        if (list.size > MAX_SELECTED_REPLIES) list.removeAt(0)

        val newArray = JSONArray().also { arr -> list.forEach { arr.put(it) } }
        obj.put("selectedReplies", newArray)

        // Mesaj sayacını artır
        val currentCount = obj.optInt("messageCount", 0)
        obj.put("messageCount", currentCount + 1)

        if (!obj.has("summary")) obj.put("summary", "")
        root.put(contactName, obj)
        writeRoot(root)
    }

    /** Tüm kayıtlı kişilerin listesi */
    suspend fun getAllContacts(): List<String> = withContext(Dispatchers.IO) {
        val root = readRoot()
        val names = mutableListOf<String>()
        val keys = root.keys()
        while (keys.hasNext()) names.add(keys.next())
        names
    }

    /** Belirli bir kişinin hafızasını sil */
    suspend fun clearContact(contactName: String) = withContext(Dispatchers.IO) {
        val root = readRoot()
        root.remove(contactName)
        writeRoot(root)
    }

    private fun readRoot(): JSONObject {
        return try {
            JSONObject(memoryFile.readText().ifBlank { "{}" })
        } catch (_: Exception) {
            JSONObject()
        }
    }

    private fun writeRoot(root: JSONObject) {
        memoryFile.writeText(root.toString(2))
    }
}
