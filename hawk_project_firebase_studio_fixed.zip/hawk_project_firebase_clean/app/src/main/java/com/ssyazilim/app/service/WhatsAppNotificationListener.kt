package com.ssyazilim.app.service

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.ssyazilim.app.data.AppPrefs

class WhatsAppNotificationListener : NotificationListenerService() {

    private lateinit var appPrefs: AppPrefs

    override fun onCreate() {
        super.onCreate()
        appPrefs = AppPrefs(this)
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        val notification = sbn ?: return
        if (notification.packageName != WHATSAPP_PACKAGE) return

        val extras = notification.notification.extras ?: return
        val title = extras.getCharSequence("android.title")?.toString().orEmpty().trim()
        val text = extras.getCharSequence("android.text")?.toString().orEmpty().trim()
        if (title.isBlank() || text.isBlank()) return

        appPrefs.lastNotificationContact = title
        appPrefs.lastNotificationText = text
        appPrefs.resetFingerprint()
        appPrefs.clearErrorLock()
        appPrefs.appendLog("Bildirim yakalandı: $title -> ${text.take(120)}")
        ChatAccessibilityService.notifyExternalMessage(title, text)
    }

    companion object {
        private const val WHATSAPP_PACKAGE = "com.whatsapp"
    }
}
