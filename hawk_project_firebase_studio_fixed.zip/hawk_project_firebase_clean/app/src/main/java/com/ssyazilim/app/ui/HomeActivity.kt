package com.ssyazilim.app.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.card.MaterialCardView
import com.ssyazilim.app.R

class HomeActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        // WhatsApp Otomasyonu kartı
        findViewById<MaterialCardView>(R.id.cardWhatsapp).setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
        }

        // Kamera İzleme kartı — Coming Soon
        findViewById<MaterialCardView>(R.id.cardCamera).setOnClickListener {
            Toast.makeText(this, "Kamera İzleme yakında geliyor! 🚀", Toast.LENGTH_SHORT).show()
        }
    }
}
