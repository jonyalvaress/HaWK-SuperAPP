package com.ssyazilim.app.model

data class ReplyResponse(
    val cold: ReplyOption,
    val normal: ReplyOption,
    val warm: ReplyOption,
    val raw: String
)
